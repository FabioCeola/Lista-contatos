# Lista-Contatos-React-Native


Introdução a React & React Native



Aplicação React Native com Expo que permita o cadastro e listagem de contatos.Contatos possuem nome e telefone. Ela contém dois campos para inserção de dados e um botão para fazer a inserção.


